<?php
//script to retreive file values


$busy = true;
  while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  
//echo "Hi";
//fclose($fp);

	//print_r($file_queue['queue'][$key]['v_count']);
    $table = "<table class='status_table' align='center'><tr><th>Customer ID</th><th> Engine </th><th> Engine Color </th><th> Engine Status </th><th> Body </th><th> Body Color</th><th> Body status </th><th> Wheel </th><th> Wheel color</th><th> Wheel status </th><th> Car Status</th></tr>";
	
	foreach($file_queue['queue'] as $key=>$value) {
		//echo $key;
		
		$row = '<tr>
                    <td>'.$file_queue['queue'][$key]['v_count'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['Engine'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['EngineColor'].'</td>
                    <td>'.$file_queue['queue'][$key]['Estat'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['Body'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['BodyColor'].'</td>
                    <td>'.$file_queue['queue'][$key]['Bstat'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['Wheel'].'</td>
                    <td>'.$file_queue['queue'][$key]['car_array']['WheelColor'].'</td>
                    <td>'.$file_queue['queue'][$key]['Wstat'].'</td>
                    <td>'.$file_queue['queue'][$key]['stat'].'</td>
                </tr>';

            $table.= $row;	  
	
	}
	echo $table."</table>";
?>
