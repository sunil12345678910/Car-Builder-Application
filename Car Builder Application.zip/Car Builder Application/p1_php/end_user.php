<?php
//Wheel manufacturer PHP Script
  $mydata = $_GET;
  $busy = true;
  while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  
  $file_queue['queue'][$mydata['userid']-1]['stat'] = 'Done!';
  //flock($file_p,LOCK_UN);
  file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);
   
?>