<?php
//script to stop session
//session_start();
file_put_contents("file_queue.json", "");
file_put_contents("engine_queue.json", "");
file_put_contents("body_queue.json", "");
file_put_contents("wheel_queue.json", "");
echo 'cleared file ';

?>
