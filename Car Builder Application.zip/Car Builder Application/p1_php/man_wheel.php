<?php
//Wheel manufacturer PHP Script
  $mydata = $_GET;
  $busy = true;
  while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  //usleep(770);
  $file_queue['queue'][$mydata['uid']-1]['Wstat'] = 'Wheel Production waiting';
  //flock($file_p,LOCK_UN);
  file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);
  


  //print_r($file_queue);
  
  $fp = fopen('wheel_queue.json', 'w+');

  if (flock($fp,LOCK_EX))
  {
    //$_SESSION['queue'][$mydata['uid']-1]['stat'] = 'Wheel Production Started';
    $busy = true;
	while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  $file_queue['queue'][$mydata['uid']-1]['Wstat'] = 'Wheel Production Started';
  file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);


    if($mydata['Wheel'] === "WheelType1")
    {
      sleep(2);
    }

    else if($mydata['Wheel'] === "WheelType2")
    {
      sleep(3);
    }

    else if($mydata['Wheel'] === "WheelType3")
    {
      sleep(4);
    }

    if($mydata['WheelColor'] !== "blue"){
      $busy = true;
	while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  $file_queue['queue'][$mydata['uid']-1]['Wstat'] = 'Wheel finished, Painting';
      file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);
      include('man_paint.php');
    }

      $busy = true;
	while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  $file_queue['queue'][$mydata['uid']-1]['Wstat'] = 'Wheel Production Finished';
    file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);


    fwrite($fp,json_encode($mydata['uid']));
  // release lock
    flock($fp,LOCK_UN);
}
else
{
echo "Error locking file!";
}

fclose($fp);

  //$_SESSION['Wman_count'] = $mydata['uid']+1;
echo "Wdone";
?>
