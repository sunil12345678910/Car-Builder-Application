<?php
//if(session_id() == '') {
//    session_start();
$fpd = file_get_contents('file_queue.json');
$file_queue = json_decode($fpd,true);
if(isset($file_queue['visit_count']))
{
    //print_r('set<br>');
     if($file_queue['visit_count'] < 4){
       $file_queue['visit_count'] ++;
       array_push($file_queue['queue'], array(
                              "car_array" => array(
                                             "Engine"=>$_GET['Engine'],
                                             "EngineColor"=>$_GET['EngineColor'],
                                             "Body"=>$_GET['Body'],
                                             "BodyColor"=>$_GET['BodyColor'],
                                             "Wheel"=>$_GET['Wheel'],
                                             "WheelColor"=>$_GET['WheelColor']
                                           ),
                              "v_count" => $file_queue['visit_count'],
                              "stat" => "in Queue",
                              "Estat" => "in Queue",
                              "Bstat" => "in Queue",
                              "Wstat" => "in Queue"
                            ));
      //echo 'You are visitor number ' . $file_queue['visit_count'].'<br>';
    //  echo json_encode($file_queue['queue']);
    echo json_encode(array(
                      "success"=>"true",
                      "uid"=>$file_queue['visit_count']));
      //var_dump($file_queue['queue']);
    }
    else{
      echo 'Assembly is Full, Please Wait';
    }
}
else
{

  $file_queue['visit_count'] = 1;
   //echo 'not set'.session_id().'<br>';
  $file_queue['queue'][] =   array(
                         "car_array" => array(
                                        "Engine"=>$_GET['Engine'],
                                        "EngineColor"=>$_GET['EngineColor'],
                                        "Body"=>$_GET['Body'],
                                        "BodyColor"=>$_GET['BodyColor'],
                                        "Wheel"=>$_GET['Wheel'],
                                        "WheelColor"=>$_GET['WheelColor']
                                      ),
                         "v_count" => $file_queue['visit_count'],
                         "stat"  => "in Queue",
                         "Estat" => "in Queue",
                         "Bstat" => "in Queue",
                         "Wstat" => "in Queue"
                         );

 $engine_queue = 0;
 $body_queue = 0;
 $wheel_queue = 0;
 $paint_queue = 0;
 // write to Car Engine queue
 $fp1 = fopen('engine_queue.json', 'w+');
 fwrite($fp1, json_encode($engine_queue));
 fclose($fp1);
 // write to Car body queue
 $fp2 = fopen('body_queue.json', 'w');
 fwrite($fp2, json_encode($body_queue));
 fclose($fp2);
 // write to Car wheel queue
  $fp3 = fopen('wheel_queue.json', 'w');
 fwrite($fp3, json_encode($wheel_queue));
 fclose($fp3);
 // write to Car paint queue
 $fp4 = fopen('paint_queue.json', 'w');
 fwrite($fp4, json_encode($paint_queue));
 fclose($fp4);
 echo json_encode(array(
                   "success"=>"true",
                   "uid"=>$file_queue['visit_count']));

}

// write to Car main queue
$fp = fopen('file_queue.json', 'w');
fwrite($fp, json_encode($file_queue));
fclose($fp);
 
?>
