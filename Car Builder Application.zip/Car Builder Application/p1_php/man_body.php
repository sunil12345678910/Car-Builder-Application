<?php
//Engine manufacturer PHP Script
  //session_start();
  $mydata = $_GET;
  $busy = true;
  //usleep(350);
  while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
  //print_r($file_queue);
  
  $file_queue['queue'][$mydata['uid']-1]['Bstat'] = 'Body Production waiting';
  //flock($file_p,LOCK_UN);
  file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);
  //fclose($file_p);
  //die();

  //fclose($fq);

  $fp = fopen('body_queue.json', 'w+');

  if (flock($fp,LOCK_EX))
  {
	$busy = true;
    while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }

    $file_queue['queue'][$mydata['uid']-1]['Bstat'] = 'Body Production Started';
    file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);


    if($mydata['Body'] === "Similar to Ford Fiesta")
    {
      sleep(2);
    }

    else if($mydata['Body'] === "Similar to Ford Fusion")
    {
      sleep(3);
    }

    else if($mydata['Body'] === "Similar to Ford Mustang")
    {
      sleep(4);
    }

    if($mydata['BodyColor'] !== "blue"){
      $busy = true;
    while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
      $file_queue['queue'][$mydata['uid']-1]['Bstat'] = 'Body Finished, Painting';
      file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);


    // release lock      flock($fp,LOCK_UN);
      include('man_paint.php');
    }

    fwrite($fp,json_encode($mydata['uid']));
    flock($fp,LOCK_UN);

    $busy = true;
    while($busy){
	$fget = file_get_contents("file_queue.json");
	$file_queue = json_decode($fget,true);
	if(array_key_exists('queue',$file_queue)){
		$busy = false;
		break;
	}
	usleep(200);
	
  }
   
    $file_queue['queue'][$mydata['uid']-1]['Bstat'] = 'Body Production Finished';
    file_put_contents("file_queue.json",json_encode($file_queue),LOCK_EX);



  }
else
  {
  echo "Error locking file!";
  }

fclose($fp);

//  $_SESSION['Bman_count'] = $mydata['uid']+1;
echo "Bdone";
?>
